# Exercise 1 - Inventory Management System 🧾

This project is part of the DeepSkill Java FSE Hands-On program.  
It is a **console-based Java application** to manage a warehouse inventory.

## Features
- Add, update, delete products
- View full inventory
- Stored using HashMap

## Files
- Product.java
- InventoryManagement.java

## How to Run
1. Compile:
   javac Product.java InventoryManagement.java
2. Run:
   java InventoryManagement

## Status
✅ Completed & Tested
