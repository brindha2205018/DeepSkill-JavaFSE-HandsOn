public class Productl{
    int productId;
    String productName;
    String productCategory;     

public Productl(int productId,String productName,String productCategory){
    this.productId=productId;
    this.productName=productName;
    this.productCategory=productCategory;
}
@Override
public String toString(){
    return "ID:"+productId+",Name:"+productName+",Category:"+productCategory;

}}