# Exercise 2 – E-commerce Platform Search Function 

This project is part of the DeepSkill Java FSE Hands-On program.  
It demonstrates two search algorithms – **Linear Search** and **Binary Search** – to find a product in an e-commerce platform.

---

Problem Statement

Develop a search functionality for an e-commerce platform.  
Users should be able to search for a product by **product ID** using:
- Linear Search (unsorted data)
- Binary Search (sorted data)

---

## Files Included

| File Name         | Description                               |
|-------------------|-------------------------------------------|
| `Productl.java`     | Defines the `Productl` class with `productId`, `productName`, and `category` |
| `Search.java`  | Main program that performs both search methods |

---

 Features

- Takes user input to search a product by ID
- Prints search result using:
  -  Linear Search
  -  Binary Search (after sorting)
- Shows time complexity of each method

---

Sample Product List

- Laptop (101)
- Sneakers (205)
- Coffee Maker (150)
- Desk Lamp (310)
- Backpack (255)

---

 How to Run

1. Open terminal in folder
2. Compile:
