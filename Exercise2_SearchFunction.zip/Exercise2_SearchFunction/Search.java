import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class Search {

    public static int linearSearch(Productl[] arr, int targetId) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i].productId == targetId) {
                return i;
            }
        }
        return -1;
    }

    public static int binarySearch(Productl[] arr, int targetId) {
        int low = 0, high = arr.length - 1;
        while (low <= high) {
            int mid = (low + high) / 2;
            if (arr[mid].productId == targetId) {
                return mid;
            } else if (arr[mid].productId < targetId) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        return -1;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of products: ");
        int n = sc.nextInt();
        sc.nextLine();

        Productl[] products = new Productl[n];

        for (int i = 0; i < n; i++) {
            System.out.println("\nEnter details for product " + (i + 1) + ":");
            System.out.print("Product ID: ");
            int id = sc.nextInt();
            sc.nextLine();

            System.out.print("Product Name: ");
            String name = sc.nextLine();

            System.out.print("Category: ");
            String category = sc.nextLine();

            products[i] = new Productl(id, name, category);
        }

        System.out.print("\nEnter product ID to search: ");
        int targetId = sc.nextInt();

        int indexLin = linearSearch(products, targetId);
        if (indexLin != -1) {
            System.out.println("\n[Linear Search] Found: " + products[indexLin]);
        } else {
            System.out.println("\n[Linear Search] Product not found.");
        }

        Arrays.sort(products, Comparator.comparingInt(p -> p.productId));

        System.out.println("\nSorted product list for Binary Search:");
        for (Productl p : products) {
            System.out.println(p);
        }

        int indexBin = binarySearch(products, targetId);
        if (indexBin != -1) {
            System.out.println("\n[Binary Search] Found: " + products[indexBin]);
        } else {
            System.out.println("\n[Binary Search] Product not found.");
        }

        System.out.println("\nTime Complexities:");
        System.out.println("Linear Search: O(n)");
        System.out.println("Binary Search: O(log n)");

        sc.close();
    }
}
